
chrome.runtime.onInstalled.addListener(() => {
  console.log('This is background.js');
});
